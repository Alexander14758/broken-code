export const eligibleWallets = {
  // SubWallet - exact IDs from your testing
  "app.subwallet": "SubWallet",
  "SubWallet": "SubWallet",
  
  // Nabox - exact IDs from your testing  
  "com.wallet.nabox": "Nabox",
  "Nabox": "Nabox"
};